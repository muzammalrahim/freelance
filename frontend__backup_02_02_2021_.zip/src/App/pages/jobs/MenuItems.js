export const MenuItems =[
  {
      title: 'Browse',
      url: '#',
      cName: 'nav-links'
  }, 
  {
    title: 'My Projects',
    url: '#',
    cName: 'nav-links'
}, 
{
    title: 'Reports',
    url: '#',
    cName: 'nav-links'
}, 
{
    title: 'Message',
    url: '#',
    cName: 'nav-links'
}, 
{
    title: 'Help',
    url: '#',
    cName: 'nav-links'
}, 
]



export const AccountSettingMenuItems =[
    {
        title: 'Browse',
        url: '#',
        cName: 'nav-links'
    }, 
    {
      title: 'My Projects',
      url: '#',
      cName: 'nav-links'
  }, 
  {
      title: 'Reports',
      url: '#',
      cName: 'nav-links'
  }, 
  {
      title: 'Message',
      url: '#',
      cName: 'nav-links'
  }, 
  
  ]