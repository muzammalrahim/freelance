import React from "react";

const NotFound = () => {
  return (
    <div style={{textAlign:"center",marginTop:"15%"}}>
      <h1 className="display-1">Error: 404</h1>
      <h1 className="display-1">Page Not Found</h1>
    </div>
  );
};

export default NotFound;