import React from 'react'
import './Or.css';
function Or() {
    return (
        <div>
            <h2><span>Or</span></h2>

        </div>
    )
}

export default Or
