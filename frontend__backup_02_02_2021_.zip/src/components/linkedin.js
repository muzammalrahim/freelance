import React from 'react'
import './linkedin.css';
function linkedin() {
    return (
        <div>
            <button className="btn-linkdin"><span className='title'> Sign up with Linked </span><i className="fab fa-linkedin"></i></button>
        </div>
    )
}

export default linkedin
