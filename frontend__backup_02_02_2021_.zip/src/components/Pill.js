import React from 'react'

function Pill() {
    return (
        <div>
            
        </div>
    )
}

export default Pill
